package c195scheduler;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Andrew
 */
public class DBConnect {
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//3.227.166.251/U05MDu";
    private static final String jdbcURL = protocol + vendorName + ipAddress;
    
    private static final String mysqlJdbcDriver = "com.mysql.jdbc.Driver"; //Driver interface reference
    static Connection conn = null;
    
    private static final String username = "U05MDu";
    private static final String password = "53688542259";
    
    public static Connection createConnection() {
        
        try {
            Class.forName(mysqlJdbcDriver);
            conn = (Connection) DriverManager.getConnection(jdbcURL, username, password);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return conn;
    }
    
    public static void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            System.out.println("ex.getMessage");
        }
    }
}
