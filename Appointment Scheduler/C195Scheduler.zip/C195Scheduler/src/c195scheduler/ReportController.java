/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import c195scheduler.database.UserImpl;
import c195scheduler.model.User;
import c195scheduler.utilities.ReportGenerator;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class ReportController implements Initializable {
    @FXML private ComboBox userSelectCB;
    @FXML private Button reportsViewCustomersButton;
    @FXML private Button reportsViewAppointmentsButton;
    
    @FXML private TabPane reportTabs;
    @FXML private Tab apptTypeTab;
    @FXML private Tab userSchedTab;
    @FXML private Tab apptDatesTab;
    
    //Appointment count by Type
    @FXML private TableView<ReportGenerator.ApptTypeList> apptTypeTable;
    @FXML private TableColumn<String, String> typeTypeReport;
    @FXML private TableColumn<Integer, Integer> apptTotalTypeReport;
    
    //Appointments by user (User Schedule)
    @FXML private TableView<ReportGenerator.ScheduleList> userSchedTable;
    @FXML private TableColumn<Integer, Integer> apptIDSchedReport;
    @FXML private TableColumn<String, String> customerNameSchedReport;
    @FXML private TableColumn<String, String> startSchedReport;
    @FXML private TableColumn<String, String> endSchedReport;
    
    ObservableList<String> userList = FXCollections.observableArrayList();
    
    //Appointments grouped by date
    @FXML private TableView<ReportGenerator.DateList> apptDateTable;    
    @FXML private TableColumn<String, String> customerNameDateReport;
    @FXML private TableColumn<String, String> userNameDateReport;
    @FXML private TableColumn<String, String> startDateReport;
    @FXML private TableColumn<String, String> endDateReport;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Add user list to combo box (User Schedule report)
        try {
            for (User u : UserImpl.getAllUsers())
                userList.add(u.getUserName());
        } catch (Exception ex) {
            ex.getMessage();
        }
        userSelectCB.setItems(userList);
        userSelectCB.getSelectionModel().selectFirst();
        userSelectCB.setVisible(false);
        
        //Bind Appt Type columns to data
        typeTypeReport.setCellValueFactory(new PropertyValueFactory<>("apptType"));
        apptTotalTypeReport.setCellValueFactory(new PropertyValueFactory<>("total"));
        
        //Bind User Schedule columns to data
        apptIDSchedReport.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        customerNameSchedReport.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        startSchedReport.setCellValueFactory(new PropertyValueFactory<>("start"));
        endSchedReport.setCellValueFactory(new PropertyValueFactory<>("end"));
        
        //Bind Appt by Date columns to data        
        customerNameDateReport.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        userNameDateReport.setCellValueFactory(new PropertyValueFactory<>("UserName"));
        startDateReport.setCellValueFactory(new PropertyValueFactory<>("start"));
        endDateReport.setCellValueFactory(new PropertyValueFactory<>("end"));
        
        apptTypeTable.setItems(ReportGenerator.getAppointmentTypes());
        apptDateTable.setItems(ReportGenerator.getAppointmentDates());
        
        //Hide userSelect ComboBox when the schedule tab is not selected
        reportTabs.getSelectionModel().selectedItemProperty().addListener(
            new ChangeListener<Tab>() {
                @Override
                public void changed(ObservableValue<? extends Tab> ov, Tab userSchedTab, Tab t1) {
                    if(!userSchedTab.isSelected())
                        userSelectCB.setVisible(false);
                    
                }
        });
        
        //Refresh schedule tab when userSelect value changed
        userSelectCB.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                Number oldValue, Number newValue) {
            User user;
                try {
                    user = UserImpl.getUser(userSelectCB.getSelectionModel().getSelectedItem().toString());
                    userSchedTable.setItems(ReportGenerator.getSchedule(user));
                } catch (Exception ex) {
                    Logger.getLogger(ReportController.class.getName()).log(Level.SEVERE, null, ex);
                }            
            }
        });
        
    }    

    @FXML private void ReportCustomersHandler(ActionEvent event) throws IOException {
        Stage stage=(Stage) reportsViewCustomersButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML private void ReportApptHandler(ActionEvent event) throws IOException {
        Stage stage=(Stage) reportsViewAppointmentsButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    //When schedule tab is selected, display the user select combo box and set table for selected user
    @FXML private void ScheduleTabHandler(Event event) throws Exception {
        userSelectCB.setVisible(true);
        User user = UserImpl.getUser(userSelectCB.getSelectionModel().getSelectedItem().toString());
        userSchedTable.setItems(ReportGenerator.getSchedule(user));
    }
}
