/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import static c195scheduler.DBConnect.conn;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Andrew
 */
public class Query {
    
    private static String query;
    private static Statement stmt;
    private static ResultSet rs;
    
    public static void createQuery(String q) {
        query = q;    
        
        try {
            stmt = conn.createStatement();
            
            // Determine whether SELECT or INSERT/UPDATE/DELETE
            if(query.toLowerCase().startsWith("select"))
                rs = stmt.executeQuery(q);
            
            if(query.toLowerCase().startsWith("delete")||query.toLowerCase().startsWith("insert")||query.toLowerCase().startsWith("update"))
                stmt.executeUpdate(q);
            
        } catch(Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
    
    public static ResultSet queryResult() {
        return rs;
    }
    
}
