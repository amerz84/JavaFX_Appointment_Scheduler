/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import c195scheduler.database.ApptImpl;
import c195scheduler.database.UserImpl;
import c195scheduler.model.User;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * USERNAME test
 * PW test
 * 
 * 
 * @author Andrew
 */
public class LoginScreenController implements Initializable {
    
    @FXML private Label credentials;
    @FXML private Label usernameLabel;
    @FXML private Label passwordLabel;
    @FXML private Button okButton;
    @FXML private Button quitButton;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
   
    ResourceBundle languageBundle;
    static User testUser;
    String usernameQuery;

        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.languageBundle = ResourceBundle.getBundle("c195scheduler/utilities/Login", Locale.getDefault());
        
        //Set UI text on login screen to resource bundle keys
        credentials.setText(languageBundle.getString("credentials"));
        usernameLabel.setText(languageBundle.getString("username"));
        passwordLabel.setText(languageBundle.getString("password"));
        okButton.setText(languageBundle.getString("OK"));
        quitButton.setText(languageBundle.getString("quit"));  
        
        usernameField.requestFocus();
    }

    @FXML private void LoginLoginHandler(ActionEvent event) throws IOException, Exception {
        String pass = passwordField.getText();
        
        //////////////////////////////////////////////////////////////////////////////////        
        // Write to log file for login attempts
        Logger log = Logger.getLogger("log.txt");        
        try {  
            FileHandler fh = new FileHandler("log.txt", true);
            SimpleFormatter sf = new SimpleFormatter();
            fh.setFormatter(sf);
            log.addHandler(fh);
       
        } catch (IOException ex) {
            Logger.getLogger(C195Scheduler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(C195Scheduler.class.getName()).log(Level.SEVERE, null, ex);
        }
        log.setLevel(Level.INFO);

//        /////////////////////////////////////////////////////////////////////////////////
//        // Authenticate user credentials
        try {            
            testUser = UserImpl.getUser(usernameField.getText());
            
            if (testUser == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText(languageBundle.getString("invalid_user"));
                alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);

                log.warning("Invalid username: " + usernameField.getText());       //Log the invalid login
            }
            else {
                                 
                if((testUser.getPassword() != null) && (testUser.getPassword().equals(pass))) {
                    log.info("Login successful: " + usernameField.getText());       //Log the successful login
                    UserImpl.setCurrentUser(testUser);                              //Track user object for current login
                    
                    if(ApptImpl.apptWithinFifteenMinutes()) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "You have an appointment starting in the next 15 minutes!", ButtonType.OK);
                        alert.setTitle("Upcoming Appointment");
                        alert.setHeaderText(null);
                        alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);
                  
                    }
                    Stage stage=(Stage) okButton.getScene().getWindow();
                    Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.centerOnScreen();
                    stage.show();
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle(null);
                    alert.setHeaderText(null);
                    alert.setContentText(languageBundle.getString("invalid_pw"));
                    alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);     
                   
                    log.warning("Invalid password for username: " + usernameField.getText());       //Log the invalid login 
                }                
               
            }

        } catch (SQLException ex) {
            System.out.println("Login Handler try block failed");
        }
    }

    @FXML private void LoginExitHandler(ActionEvent event) {
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to quit the program?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            DBConnect.closeConnection();
            System.exit(0);
        } else {
            alert.close();
        }     
    }
    
    private void showLoginScreen(ActionEvent event) {
         try {
            ((Node) (event.getSource())).getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } 
        catch(IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void showMainScreen(ActionEvent event) {
        try {
            Stage stage;        
            stage=(Stage) okButton.getScene().getWindow();
            //load up OTHER FXML document
            Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
}
