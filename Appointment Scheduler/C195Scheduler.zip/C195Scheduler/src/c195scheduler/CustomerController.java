/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import static c195scheduler.DBConnect.conn;
import c195scheduler.database.AddressImpl;
import c195scheduler.database.CityImpl;
import c195scheduler.database.CountryImpl;
import c195scheduler.database.CustomerImpl;
import c195scheduler.database.UserImpl;
import c195scheduler.model.Address;
import c195scheduler.model.City;
import c195scheduler.model.Country;
import c195scheduler.model.Customer;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class CustomerController implements Initializable {
    int maxID = 0;          // Max ID of customer table to avoid duplicates
    ObservableList<String> customerList = FXCollections.observableArrayList();

    @FXML private Button customerAddButton;
    @FXML private Button customerBackButton;
    @FXML private Button customerUpdateButton;
    @FXML private Button customerDeleteButton;
    @FXML private TableView<Customer> customerTable;
    @FXML private TableColumn<Customer, Integer> customerID;
    @FXML private TableColumn<Customer, String> custName;
    
    //Add/update side panel
    @FXML private Pane addOrUpdatePane;
    @FXML private Label addCustLabel;
    @FXML private Label addCustNameLabel;
    @FXML private Label addAddressLabel;
    @FXML private Label addCityLabel;
    @FXML private Label addZipLabel;
    @FXML private Label addCountryLabel;
    @FXML private Label addCustPhoneLabel;
    @FXML private TextField custNameField;
    @FXML private TextField custAddressField;
    @FXML private TextField custCityField;
    @FXML private TextField custZipField;
    @FXML private TextField custCountryField;
    @FXML private TextField custPhoneField;
    @FXML private Button custSave;
    @FXML private Button custUpdate;
    @FXML private Button custCancel;
   
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        custName.setCellValueFactory(new PropertyValueFactory<>("CustomerName"));
        customerID.setCellValueFactory(new PropertyValueFactory<>("CustomerID"));
        
        try {
            customerTable.setItems(CustomerImpl.getAllCustomers());
        } catch (Exception ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        hideSidePanel();
    } 
    
    //Cancel add/update customer
    @FXML private void CustomerCancelHandler(ActionEvent event) throws IOException {
        Stage stage;
        stage=(Stage) customerBackButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //Display form to add new customer
    @FXML private void AddCustomerHandler(ActionEvent event) {
        showSidePanel();
        addCustLabel.setText("Add a customer");
        custSave.setVisible(true);
    }
    
    //Creates a new customer object (and associated address, city, country if needed)
    @FXML private void SaveNewCustomerHandler(ActionEvent event) throws SQLException, Exception {
        String userName = UserImpl.getCurrentUser().getUserName();
        maxID = CustomerImpl.findMaxCustomerId();       //Prevent re-use of primary key value
        int maxAddressID = AddressImpl.findMaxAddressId();
        int maxCityID = CityImpl.findMaxCityId();
        int maxCountryID = CountryImpl.findMaxCountryId();
        int addressID;
        int cityID;
        int countryID;

        //Capture form data, prepare variables to pass to SQL statement
        String name = custNameField.getText();
        String streetAddress = custAddressField.getText();
        String city = custCityField.getText();
        String zipCode = custZipField.getText();
        String country = custCountryField.getText();
        String phone = custPhoneField.getText();
        //Validate form data (check for empty fields) - Will throw error and return if any fields empty
        if(!isDataValid(name) || !isDataValid(streetAddress) || !isDataValid(city) || !isDataValid(zipCode) || !isDataValid(country) || !isDataValid(phone)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(null);
            alert.setHeaderText(null);
            alert.setContentText("Please enter data for all form fields");
            alert.showAndWait()
                .filter(res -> res == ButtonType.OK);

            return;
        }

        /////----------------If customer's address doesn't exist, create a new address record
        /////----------------If customer's city doesn't exist, create a new city record
        /////----------------If customer's country doesn't exist, create a new country record
        
        //////////////Check if address already exists
        List<Address> existingAddress = Address.getAddresses().stream()
            .filter(a -> a.getAddress().equalsIgnoreCase(streetAddress))        /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());  
        List<City> existingCity = City.getCities().stream()
            .filter(a -> a.getCity().equalsIgnoreCase(city))        /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());
        List<Country> existingCountry = Country.getCountries().stream()
            .filter(a -> a.getCountry().equalsIgnoreCase(country))        /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());        
        
        if(!existingCountry.isEmpty()) {    //Returns true if there is a matching country
            countryID = existingCountry.get(0).getCountryID();
        }
        else{                               //Create new country if no match is found
            countryID = ++maxCountryID;
            String createNewCountry = "INSERT INTO country"
                + " VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewCountry);
            prepStmt.setInt(1, countryID);
            prepStmt.setString(2, country);
            prepStmt.setTimestamp(3, Timestamp.from(Instant.now()));
            prepStmt.setString(4, userName);
            prepStmt.setTimestamp(5, Timestamp.from(Instant.now()));
            prepStmt.setString(6, userName);
            prepStmt.execute();
        }
        
        if(!existingCity.isEmpty()) {           //Returns true if there is a matching city
            cityID = existingCity.get(0).getCityID();
        }            
        else {                                  //Create new city if no match is found
            cityID = ++maxCityID;
            String createNewCity = "INSERT INTO city"
                    + " VALUES(?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewCity);
            prepStmt.setInt(1, cityID);
            prepStmt.setString(2, city);
            prepStmt.setInt(3, countryID);
            prepStmt.setTimestamp(4, Timestamp.from(Instant.now()));
            prepStmt.setString(5, userName);
            prepStmt.setTimestamp(6, Timestamp.from(Instant.now()));
            prepStmt.setString(7, userName);
            prepStmt.execute();                            
        }
                    
        if(!existingAddress.isEmpty()) {            //Returns true if there is a matching address
            addressID = existingAddress.get(0).getAddressID();
        }        
        else {                                      //Create new address if no match is found, then create new customer
            addressID = ++maxAddressID;           
        
            String createNewAddress = "INSERT INTO address"
                + " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewAddress);
            prepStmt.setInt(1, addressID);
            prepStmt.setString(2, streetAddress);
            prepStmt.setString(3, "");
            prepStmt.setInt(4, cityID);
            prepStmt.setString(5, zipCode);
            prepStmt.setString(6, phone);
            prepStmt.setTimestamp(7, Timestamp.from(Instant.now()));
            prepStmt.setString(8, userName);
            prepStmt.setTimestamp(9, Timestamp.from(Instant.now()));
            prepStmt.setString(10, userName);
            prepStmt.execute();
            }      

        String createNewCustomer = "INSERT INTO customer"
            + " VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewCustomer);
            if (maxID > 0) {
                prepStmt.setInt(1, ++maxID);
            }
            else System.out.println("Error assigning Customer ID.");
            
            prepStmt.setString(2, name);
            prepStmt.setInt(3, addressID);
            prepStmt.setBoolean(4, true);
            prepStmt.setTimestamp(5, Timestamp.from(Instant.now()));
            prepStmt.setString(6, userName);
            prepStmt.setTimestamp(7, Timestamp.from(Instant.now()));
            prepStmt.setString(8, userName);
            prepStmt.execute(); 
                
        Stage stage;         
        stage=(Stage) customerDeleteButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    //Updates existing customer object with form input
    @FXML private void SaveUpdateCustomerHandler(ActionEvent event) throws SQLException, Exception {
        Customer selectedCustomer = customerTable.getSelectionModel().getSelectedItem();
        String userName = UserImpl.getCurrentUser().getUserName();
        int addressID = 0;
        int cityID = 0;
        int countryID = 0;
        int maxAddressID = AddressImpl.findMaxAddressId();
        int maxCityID = CityImpl.findMaxCityId();
        int maxCountryID = CountryImpl.findMaxCountryId();
        
        //Capture form data, prepare variables to pass to SQL statement
        //Use data from selectedCustomer if fields are left blank        
        String name = (custNameField.getText().isEmpty()) ? 
                selectedCustomer.getCustomerName() : 
                custNameField.getText();
        String streetAddress = (custAddressField.getText().isEmpty()) ? 
                Address.getAddresses().get(selectedCustomer.getAddressID() - 1).getAddress() :
                custAddressField.getText();
        String city = (custCityField.getText().isEmpty()) ? 
                City.getCities().get(Address.getAddresses().get(selectedCustomer.getAddressID() - 1).getCityID() - 1).getCity() : 
                custCityField.getText();
        String zipCode = (custZipField.getText().isEmpty()) ?
                Address.getAddresses().get(selectedCustomer.getAddressID() - 1).getPostalCode() :
                custZipField.getText();
        String country = (custCountryField.getText().isEmpty()) ?
                Country.getCountries().get(City.getCities().get(Address.getAddresses().get(selectedCustomer.getAddressID() - 1).getCityID() - 1).getCountryID() - 1).getCountry() :
                custCountryField.getText();
        String phone = (custPhoneField.getText().isEmpty()) ?
                Address.getAddresses().get(selectedCustomer.getAddressID() - 1).getPhone() :
                custPhoneField.getText();
        
        /////----------------If customer's address doesn't exist, create a new address record
        /////----------------If customer's city doesn't exist, create a new city record
        /////----------------If customer's country doesn't exist, create a new country record
        
        //////////////Check if address/city/country already exists
        List<Address> existingAddress = Address.getAddresses().stream()
            .filter(a -> a.getAddress().equalsIgnoreCase(streetAddress))        /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());  
        List<City> existingCity = City.getCities().stream()
            .filter(a -> a.getCity().equalsIgnoreCase(city))                    /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());
        List<Country> existingCountry = Country.getCountries().stream()
            .filter(a -> a.getCountry().equalsIgnoreCase(country))              /////// Lambda used as a filter parameter for concise code
            .collect(Collectors.toList());
        
        ///////////////////////////////////////////////////////////////////////////////////
        if(!existingCountry.isEmpty()) {    //Returns true if there is a matching country
            countryID = existingCountry.get(0).getCountryID();
        }
        else {                               //Create new country if no match is found
            countryID = ++maxCountryID;
            String createNewCountry = "INSERT INTO country"
                + " VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewCountry);
            prepStmt.setInt(1, countryID);
            prepStmt.setString(2, country);
            prepStmt.setTimestamp(3, Timestamp.from(Instant.now()));
            prepStmt.setString(4, userName);
            prepStmt.setTimestamp(5, Timestamp.from(Instant.now()));
            prepStmt.setString(6, userName);
            prepStmt.execute();            
        }
        
        ///////////////////////////////////////////////////////////////////////////////////
        if(!existingCity.isEmpty()) {           //Returns true if there is a matching city
            cityID = existingCity.get(0).getCityID();
        }            
        else {                                  //Create new city if no match is found 
            cityID = ++maxCityID;
            String createNewCity = "INSERT INTO city"
                + " VALUES(?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewCity);
            prepStmt.setInt(1, cityID);
            prepStmt.setString(2, city);
            prepStmt.setInt(3, countryID);
            prepStmt.setTimestamp(4, Timestamp.from(Instant.now()));
            prepStmt.setString(5, userName);
            prepStmt.setTimestamp(6, Timestamp.from(Instant.now()));
            prepStmt.setString(7, userName);
            prepStmt.execute();     
        }
        
        if(!existingAddress.isEmpty()) {            //Returns true if there is a matching address
            addressID = existingAddress.get(0).getAddressID();
        }        
        else {                                      //Create new address if no match is found, then update customer                       
            addressID = ++maxAddressID;
            String createNewAddress = "INSERT INTO address"
                + " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement prepStmt = conn.prepareStatement(createNewAddress);
            prepStmt.setInt(1, addressID);
            prepStmt.setString(2, streetAddress);
            prepStmt.setString(3, "");
            prepStmt.setInt(4, cityID);
            prepStmt.setString(5, zipCode);
            prepStmt.setString(6, phone);
            prepStmt.setTimestamp(7, Timestamp.from(Instant.now()));
            prepStmt.setString(8, userName);
            prepStmt.setTimestamp(9, Timestamp.from(Instant.now()));
            prepStmt.setString(10, userName);
            prepStmt.execute();  
        }

        String updatedCustomer = "UPDATE customer SET"
            + " customerName = ?, addressId = ?, active = ?, lastUpdate = ?, lastUpdateBy = ?"
            + " WHERE customerId = ?";
            PreparedStatement prepStmt = conn.prepareStatement(updatedCustomer);            
            prepStmt.setString(1, name);
            prepStmt.setInt(2, addressID);
            prepStmt.setBoolean(3, true);
            prepStmt.setTimestamp(4, Timestamp.from(Instant.now()));
            prepStmt.setString(5, userName);
            prepStmt.setInt(6, selectedCustomer.getCustomerID());
            prepStmt.execute(); 
            
        String updatedAddress = "UPDATE address SET"
            + " cityId = ?, postalCode = ?, phone = ?"
            + " WHERE addressId = ?";
            prepStmt = conn.prepareStatement(updatedAddress);
            prepStmt.setInt(1, cityID);
            prepStmt.setString(2, zipCode);
            prepStmt.setString(3, phone);
            prepStmt.setInt(4, addressID);
            prepStmt.execute();
            
        String updatedCity = "UPDATE city SET"
            + " countryId = ?"
            + " WHERE cityId = ?";
            prepStmt = conn.prepareStatement(updatedCity);
            prepStmt.setInt(1, countryID);
            prepStmt.setInt(2, cityID);
            prepStmt.execute();
                                
        Stage stage;         
        stage=(Stage) customerDeleteButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
    }

    //Display update customer form
    @FXML private void UpdateCustomerHandler(ActionEvent event) throws SQLException {        
        Customer customer = customerTable.getSelectionModel().getSelectedItem();        

        if (customer != null) {
            showSidePanel();
            addCustLabel.setText("Update a customer");
            custUpdate.setVisible(true);

            String query = "SELECT c.customerName, a.address, ci.city, co.country, a.phone, a.postalCode\n" +
                "FROM customer c JOIN address a ON c.addressId = a.addressId\n" +
                "JOIN city ci ON a.cityId = ci.cityId\n" +
                "JOIN country co ON ci.countryId = co.countryId\n" +
                "WHERE c.customerId = " + customer.getCustomerID();
            Query.createQuery(query);
            ResultSet rs = Query.queryResult();

            while (rs.next()) {
                custNameField.setText(rs.getString("customerName"));
                custAddressField.setText(rs.getString("address"));
                custCityField.setText(rs.getString("city"));
                custZipField.setText(rs.getString("postalCode"));
                custCountryField.setText(rs.getString("country"));
                custPhoneField.setText(rs.getString("phone"));
            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(null);
            alert.setHeaderText(null);
            alert.setContentText("Please select a customer to update.");
            alert.showAndWait()
                .filter(res -> res == ButtonType.OK);
        }
    }

    //Delete selected customer from underlying database
    @FXML private void DeleteCustomerHandler(ActionEvent event) throws IOException {
        Customer cust = customerTable.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete this customer?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            try {
                CustomerImpl.deleteCustomer(cust.getCustomerID());
            } catch (Exception ex) {
                System.out.println("Error attempting to delete customer record.");
            }
        } else {
        alert.close();
        }
        
        Stage stage;         
        stage=(Stage) customerDeleteButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
     private void showSidePanel() {    
        customerAddButton.setVisible(false);
        customerUpdateButton.setVisible(false);
        customerDeleteButton.setVisible(false);
        addOrUpdatePane.setVisible(true);
        addCustLabel.setVisible(true);
        addCustNameLabel.setVisible(true);
        addAddressLabel.setVisible(true);
        addCityLabel.setVisible(true);
        addZipLabel.setVisible(true);
        addCountryLabel.setVisible(true);
        addCustPhoneLabel.setVisible(true);
        custNameField.setVisible(true);
        custAddressField.setVisible(true);
        custCityField.setVisible(true);
        custZipField.setVisible(true);
        custCountryField.setVisible(true);
        custPhoneField.setVisible(true);        
        custCancel.setVisible(true);
    }

    private void hideSidePanel() {
        customerAddButton.setVisible(true);
        customerUpdateButton.setVisible(true);
        customerDeleteButton.setVisible(true);
        addOrUpdatePane.setVisible(false);
        addCustLabel.setVisible(false);
        addCustNameLabel.setVisible(false);
        addAddressLabel.setVisible(false);
        addCityLabel.setVisible(false);
        addZipLabel.setVisible(false);
        addCountryLabel.setVisible(false);
        addCustPhoneLabel.setVisible(false);
        custNameField.setVisible(false);
        custAddressField.setVisible(false);
        custCityField.setVisible(false);
        custZipField.setVisible(false);
        custCountryField.setVisible(false);
        custPhoneField.setVisible(false);
        custSave.setVisible(false);
        custUpdate.setVisible(false);
        custCancel.setVisible(false);
    }
    
    //Check for empty fields in the save/update form
    private boolean isDataValid(String str) {
        Boolean b = false;
        if(!str.trim().isEmpty()) {
            b = true;
        }
        return b;
    }

    //Return to main appointment screen
    @FXML private void CustomerBackHandler(ActionEvent event) throws IOException {
        Stage stage;         
        stage=(Stage) customerDeleteButton.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }   

}
