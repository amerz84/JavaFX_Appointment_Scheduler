/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import static c195scheduler.DBConnect.conn;
import c195scheduler.database.ApptImpl;
import c195scheduler.database.CustomerImpl;
import c195scheduler.database.UserImpl;
import c195scheduler.model.Appointment;
import c195scheduler.model.Customer;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Comparator;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 * 
 * 
 * USERNAME test
 * PW test
 *
 * @author Andrew
 */
public class MainScreenController implements Initializable {
    static int hourOffset = 0;      //Equal to either 12 or 0 depending on if start/end time is AM or PM
    int maxId = 0;           //Max appointmentID value to avoid duplicates
    String zoneOffset = OffsetDateTime.now().getOffset().toString();
        
    @FXML private Button mainCustomers;
    @FXML private Button mainAppointmentsAddButton;
    @FXML private Button mainAppointmentsUpdateButton;
    @FXML private Button mainAppointmentsDeleteButton;
    @FXML private RadioButton mainMonthRadioButton;
    @FXML private RadioButton mainWeekRadioButton;
    @FXML private Button mainReports;
    @FXML private ToggleGroup appointments;
    
    // Add/update appointment panel elements
    @FXML private Pane addOrUpdatePane;
    @FXML private Label addApptLabel;
    @FXML private Label addApptTypeLabel;
    @FXML private Label addApptFromLabel;
    @FXML private Label addApptDurationLabel;
    @FXML private DatePicker startPicker;
    @FXML private ComboBox apptStartHour;
    @FXML private ComboBox apptStartMinute;
    @FXML private ComboBox apptDuration;
    @FXML private ComboBox apptCustomer;
    @FXML private TextField apptType;
    @FXML private Button apptSave;
    @FXML private Button apptUpdate;
    @FXML private Button apptCancel;
    @FXML private RadioButton am;
    @FXML private RadioButton pm;
    @FXML private ToggleGroup amPmToggle;
    
    @FXML private TableView<Appointment> apptTable;
    @FXML private TableColumn<Appointment, Integer> appointmentID;
    @FXML private TableColumn<Appointment, Integer> customerID;
    @FXML private TableColumn<Appointment, Integer> userID;
    @FXML private TableColumn<Appointment, String> title;
    @FXML private TableColumn<Appointment, String> description;
    @FXML private TableColumn<Appointment, String> location;
    @FXML private TableColumn<Appointment, String> contact;
    @FXML private TableColumn<Appointment, String> type;
    @FXML private TableColumn<Appointment, String> url;
    @FXML private TableColumn<Appointment, ZonedDateTime> createDate;
    @FXML private TableColumn<Appointment, String> createdBy;
    @FXML private TableColumn<Appointment, ZonedDateTime> lastUpdate;
    @FXML private TableColumn<Appointment, String> lastUpdateBy;
    @FXML private TableColumn<Appointment, ZonedDateTime> apptStart;
    @FXML private TableColumn<Appointment, ZonedDateTime> apptEnd;
    ObservableList<Appointment> apptList = FXCollections.observableArrayList();
    ObservableList<String> minutesCombo = FXCollections.observableArrayList("00", "15", "30", "45");
    ObservableList<String> hoursCombo = FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12");
    ObservableList<String> apptDurationCombo = FXCollections.observableArrayList("15", "30", "45", "60");
    ObservableList<String> customerList = FXCollections.observableArrayList();

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL urlx, ResourceBundle rb) {
               
        //Bind table columns to Appointment data
        appointmentID.setCellValueFactory(new PropertyValueFactory<>("AppointmentID"));
        customerID.setCellValueFactory(new PropertyValueFactory<>("CustomerID"));
        userID.setCellValueFactory(new PropertyValueFactory<>("UserID"));
        title.setCellValueFactory(new PropertyValueFactory<>("Title"));
        description.setCellValueFactory(new PropertyValueFactory<>("Description"));
        location.setCellValueFactory(new PropertyValueFactory<>("Location"));
        contact.setCellValueFactory(new PropertyValueFactory<>("Contact"));
        type.setCellValueFactory(new PropertyValueFactory<>("Type"));
        url.setCellValueFactory(new PropertyValueFactory<>("URL"));
        createDate.setCellValueFactory(new PropertyValueFactory<>("CreateDate"));
        createdBy.setCellValueFactory(new PropertyValueFactory<>("CreatedBy"));
        lastUpdate.setCellValueFactory(new PropertyValueFactory<>("LastUpdate"));
        lastUpdateBy.setCellValueFactory(new PropertyValueFactory<>("LastUpdateBy"));
        apptStart.setCellValueFactory(new PropertyValueFactory<>("start"));
        apptEnd.setCellValueFactory(new PropertyValueFactory<>("End"));
        

        //Set date options for DatePicker (Limited to weekdays)
        startPicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(
                    empty || 
                    date.getDayOfWeek() == DayOfWeek.SATURDAY || 
                    date.getDayOfWeek() == DayOfWeek.SUNDAY ||
                    date.isBefore(LocalDate.now()));
                if(date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY || date.isBefore(LocalDate.now())) {
                    setStyle("-fx-background-color: GRAY;");
                }
            }
        });
        
        // Populate Combo Boxes for add/update Appointment
        apptStartHour.setItems(hoursCombo);
        apptStartMinute.setItems(minutesCombo);
        apptDuration.setItems(apptDurationCombo);        
        try {
            for (Customer c : CustomerImpl.getAllCustomers())
                customerList.add(c.getCustomerName());
        } catch (Exception ex) {
            Logger.getLogger(MainScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        customerList.sort((name1, name2) -> name1.compareTo(name2));            //Lambda for concise code -- sort alphabetically by name
        apptCustomer.setItems(customerList);
        
        // Populate Appointment list in table view
        try {
            apptList.addAll(ApptImpl.getAllAppointments());    
        } catch (Exception ex) {
            Logger.getLogger(MainScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }            
        apptList.sort(Comparator.comparing(appt -> appt.getStart()));           //Lambda for concise code -- sort appointments by start dateTime
        apptTable.setItems(apptList);
        hideSidePanel();
    }   
    
    //Quit program
    private void MainExitHandler(ActionEvent event) {
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to quit the program?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            DBConnect.closeConnection();
            System.exit(0);
        } else {
            alert.close();
        }     
    }
    
    //Show Customer screen
    @FXML private void MainCustomersHandler(ActionEvent event) throws IOException {
        Stage stage;         
        stage=(Stage) mainCustomers.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //Show Report screen
    @FXML private void MainReportHandler(ActionEvent event) throws IOException {
        Stage stage;         
        stage=(Stage) mainReports.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Report.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //Create or modify appointment and add appt to apptList
    @FXML private void ApptSaveHandler(ActionEvent event) throws IOException {        
        String createNewAppt;       //SQL INSERT statement
        int apptCustID = 0;
        maxId = ApptImpl.findMaxApptId();       //Prevent re-use of primary key value
        Integer sHour = Integer.valueOf((String) apptStartHour.getValue());
        
        //Capture form data, prepare variables to pass to SQL statement
        
        LocalTime apptTime = LocalTime.of(Integer.valueOf((String) apptStartHour.getValue()) + hourOffset, Integer.valueOf((String) apptStartMinute.getValue()));    //Appointment time
        LocalDate apptDate = startPicker.getValue();                    //Appointment date
        Long apptLength = Long.valueOf((String) apptDuration.getValue());               //Appointment duration
        int userID = UserImpl.getCurrentUser().getUserID();        //ID of logged-in user who is creating appointment
        String userName = UserImpl.getCurrentUser().getUserName();
        String type = apptType.getText();                               //Appointment type
        
        //Prevent apptStartHour from being saved as values 5-7 (outside of business hours regardless of AM/PM)
        if (sHour >= 5 )
        
        try {
            apptCustID = CustomerImpl.getCustomer(apptCustomer.getValue().toString()).getCustomerID();      //ID of selected customer
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        //Convert start and end to timestamp to store in DB
        LocalDateTime localApptStart = LocalDateTime.of(apptDate, apptTime);
        Timestamp startTimestamp = Timestamp.valueOf(localApptStart);        
        LocalDateTime localApptEnd = localApptStart.plusMinutes(apptLength);
        Timestamp endTimestamp = Timestamp.valueOf(localApptEnd);
        
        try {
            //Check for conflict with existing appointment
            if (!ApptImpl.isOverlapping(userID, localApptStart, localApptEnd)){                
                // Add new appointment to list if it doesn't overlap with existing
                createNewAppt = "INSERT INTO appointment"
                        + " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, CONVERT_TZ(?, '" + zoneOffset + "', '+00:00'), CONVERT_TZ(?, '" + zoneOffset + "', '+00:00'), ?, ?, ?, ?)";
                PreparedStatement prepStmt = conn.prepareStatement(createNewAppt);
                if (maxId > 0) {
                    prepStmt.setInt(1, ++maxId) ;
                }
                else {
                    System.out.println("idCount error");
                        }
                prepStmt.setInt(2, apptCustID);
                prepStmt.setInt(3, userID);
                prepStmt.setString(4, null);
                prepStmt.setString(5, null);
                prepStmt.setString(6, null);
                prepStmt.setString(7, null);
                prepStmt.setString(8, type);
                prepStmt.setString(9, null);
                prepStmt.setTimestamp(10, startTimestamp);
                prepStmt.setTimestamp(11, endTimestamp);
                prepStmt.setTimestamp(12, Timestamp.from(Instant.now()));
                prepStmt.setString(13, userName);
                prepStmt.setTimestamp(14, Timestamp.from(Instant.now()));
                prepStmt.setString(15, userName);
                prepStmt.execute(); 

            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("There is an existing appointment during the selected times.");
                alert.showAndWait()
                    .filter(res -> res == ButtonType.OK);
            }
        } catch (Exception ex) {
            Logger.getLogger(MainScreenController.class.getName()).log(Level.WARNING, null, ex);
        }
        
        Stage stage;         
        stage=(Stage) mainCustomers.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
        //Update selected appointment
    @FXML private void ApptUpdateHandler(ActionEvent event) throws IOException {        
        Appointment selectedAppt = new Appointment();
        LocalTime apptTime = LocalTime.now();
        Long apptLength = null;
        int apptCustID = 0; 
        
        if ((selectedAppt = apptTable.getSelectionModel().getSelectedItem()) != null) {
            //Capture form data, prepare variables to pass to SQL statement
            if(apptStartHour.getValue() == null || apptStartMinute.getValue() == null) {        //Error if minute/hour is selected but not both
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("Please enter both a date and a start time.");
                alert.showAndWait()
                    .filter(res -> res == ButtonType.OK);
                return;
            }
            else {
                apptTime = LocalTime.of(Integer.valueOf((String) apptStartHour.getValue()) + hourOffset, Integer.valueOf((String) apptStartMinute.getValue()));   
            }
            
            LocalDate apptDate = startPicker.getValue();                    //Appointment date
            if(apptDuration.getValue() != null) {
                apptLength = Long.valueOf((String) apptDuration.getValue());                    //Appointment duration
            }
            int userID = UserImpl.getCurrentUser().getUserID();        //ID of logged-in user who is creating appointment
            String userName = UserImpl.getCurrentUser().getUserName();
            String type = (apptType.getText().isEmpty()) ? selectedAppt.getType() : apptType.getText();                               //If type isn't selected, use type from selected table entry

            try {
                apptCustID = (apptCustomer.getSelectionModel().isEmpty()) ? selectedAppt.getCustomerID() : CustomerImpl.getCustomer(apptCustomer.getValue().toString()).getCustomerID();      //If not chosen, use Customer ID of table selection
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }

            if((apptDate != null && apptTime == null) || (apptDate == null && apptTime != null)) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("Please enter both a date and a start time.");
                alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);
                return;
            }
            else{
                LocalDateTime localApptStart = LocalDateTime.of(apptDate, apptTime);
                Timestamp startTimestamp = Timestamp.valueOf(localApptStart);

                LocalDateTime localApptEnd = (apptLength == null) ? LocalDateTime.parse(selectedAppt.getEnd()) : localApptStart.plusMinutes(apptLength);           //If duration wasn't chosen, use appointment end of selected table item
                Timestamp endTimestamp = Timestamp.valueOf(localApptEnd);


                try {
                    //Check for conflict with existing appointment
                    if (!ApptImpl.isOverlapping(userID, localApptStart, localApptEnd)){
                        // Add new appointment to list if it doesn't overlap with existing
                        String createNewAppt = "UPDATE appointment SET"
                                + " customerId = ?, userId = ?, type = ?, start = CONVERT_TZ(?, '" + zoneOffset + "', '+00:00'),"
                                + " end = CONVERT_TZ(?, '" + zoneOffset + "', '+00:00'), lastUpdate = ?, lastUpdateBy = ?"
                                + " WHERE appointmentId = ?";
                        PreparedStatement prepStmt = conn.prepareStatement(createNewAppt);

                        prepStmt.setInt(1, apptCustID);
                        prepStmt.setInt(2, userID);
                        prepStmt.setString(3, type);
                        prepStmt.setTimestamp(4, startTimestamp);
                        prepStmt.setTimestamp(5, endTimestamp);
                        prepStmt.setTimestamp(6, Timestamp.from(Instant.now()));
                        prepStmt.setString(7, userName);
                        prepStmt.setInt(8, selectedAppt.getAppointmentID());
                        prepStmt.execute(); 

                    }
                    else{
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle(null);
                        alert.setHeaderText(null);
                        alert.setContentText("There is an existing appointment during the selected times.");
                        alert.showAndWait()
                            .filter(res -> res == ButtonType.OK);
                    }
                } catch (Exception ex) {
                    Logger.getLogger(MainScreenController.class.getName()).log(Level.WARNING, null, ex);
                }
            }

            Stage stage;         
            stage=(Stage) mainCustomers.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        else System.out.println("Please select an appointment to update.");
    }
    
    //Toggle display between Weekly/Monthly appointments
    @FXML private void MainRadioHandler(ActionEvent event) {
        if(mainMonthRadioButton.isSelected())
            try {
                apptList.clear();
                apptList.addAll(ApptImpl.getAllAppointments());    
            } catch (Exception ex) {
                ex.getMessage();
            }
            
        if(mainWeekRadioButton.isSelected())
            try {
                apptList.clear();
                apptList.addAll(ApptImpl.getWeeklyAppointments());                 
            } catch (Exception ex) {
                ex.getMessage();
            }
       
        apptTable.refresh();
    }

    //Close side panel without making any changes
    @FXML private void ApptCancelHandler(ActionEvent event) {
        startPicker.setValue(null);
        apptType.clear();
        apptStartHour.setValue(null);
        apptStartMinute.setValue(null);
        apptDuration.setValue(null);
        apptCustomer.setValue(null);
        hideSidePanel();
    }

    //Show side panel for creating a new appointment
    @FXML private void MainApptAddHandler(ActionEvent event) {
        showSidePanel();   
        addApptLabel.setText("Add an appointment");
        apptSave.setVisible(true);
        am.setVisible(true);
        pm.setVisible(true);
    }

    //Show side panel for updating an existing appointment
    @FXML private void MainApptUpdateHandler(ActionEvent event) {
        Appointment appt = apptTable.getSelectionModel().getSelectedItem();
        
        if (appt != null) {
            showSidePanel();
            addApptLabel.setText("Update an appointment");
            apptUpdate.setVisible(true);
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("Please select an appointment to update");
                alert.showAndWait()
                        .filter(res -> res == ButtonType.OK); 
        }
    }

    //Delete selected appointment from database
    @FXML private void MainApptDeleteHandler(ActionEvent event) throws Exception {
        Appointment appt = apptTable.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete this appointment?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            ApptImpl.deleteAppt(appt.getAppointmentID());
        } else {
        alert.close();
        }
        
        Stage stage;         
        stage=(Stage) mainCustomers.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //Quit program
    @FXML private void MainExitHandler(MouseEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to quit the program?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            DBConnect.closeConnection();
            System.exit(0);
        } else {
            alert.close();
        }        
    }
    
    private void showSidePanel() {    
        mainAppointmentsAddButton.setVisible(false);
        mainAppointmentsUpdateButton.setVisible(false);
        mainAppointmentsDeleteButton.setVisible(false);
        addOrUpdatePane.setVisible(true);
        addApptLabel.setVisible(true);
        addApptTypeLabel.setVisible(true);
        startPicker.setVisible(true);
        apptStartHour.setVisible(true);
        apptStartMinute.setVisible(true);
        apptDuration.setVisible(true);
        addApptFromLabel.setVisible(true);
        addApptDurationLabel.setVisible(true);
        apptCustomer.setVisible(true);
        apptType.setVisible(true);        
        apptCancel.setVisible(true);
    }

    private void hideSidePanel() {
        mainAppointmentsAddButton.setVisible(true);
        mainAppointmentsUpdateButton.setVisible(true);
        mainAppointmentsDeleteButton.setVisible(true);
        addOrUpdatePane.setVisible(false);
        addApptLabel.setVisible(false);
        addApptTypeLabel.setVisible(false);
        startPicker.setVisible(false);
        apptStartHour.setVisible(false);
        apptStartMinute.setVisible(false);
        apptDuration.setVisible(false);
        addApptFromLabel.setVisible(false);
        addApptDurationLabel.setVisible(false);
        apptCustomer.setVisible(false);
        apptType.setVisible(false);
        apptSave.setVisible(false);
        apptUpdate.setVisible(false);
        apptCancel.setVisible(false);
    }

    //Set form text to "AM" or "PM" depending on the hour value selected
    //--If between one and four PM, a value of 12 will also be added to the appointment start/end times (1:00 pm -> 13:00 hours)
    @FXML private void SetAmPmHandler(ActionEvent event) {
        hourOffset = 0;
        Integer sHour = Integer.valueOf((String) apptStartHour.getValue());
        if(sHour >= 1 && sHour <= 4){
            pm.setSelected(true);
            hourOffset = 12;
        }
        else if(sHour == 12) {
            pm.setSelected(true);
        }
        
        else if (sHour >= 5 && sHour <= 7){
            am.setSelected(false);
            pm.setSelected(false);
        }
        else am.setSelected(true);
    }
    
    // Limit appointment times to regular business hours and alert if manually set outside bus. hrs.
    // Proactively set AM or PM radio button depending on hour chosen    
    @FXML private void AmPmRadioHandler(ActionEvent event) {
        Integer sHour = Integer.valueOf((String) apptStartHour.getValue());

       if ((sHour == 12 || sHour <= 4) && am.isSelected()) {
           pm.setSelected(true);
           Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("Start time is outside of business hours - please select a valid start time");
                alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);              
       }
       
       else if (sHour > 4) {
           if (sHour >= 8 && pm.isSelected()) {
               am.setSelected(true);
           }
           else {
           am.setSelected(false);
           pm.setSelected(false);
           }
           Alert alert = new Alert(Alert.AlertType.ERROR);
           alert.setTitle(null);
                alert.setHeaderText(null);
                alert.setContentText("Start time is outside of business hours - please select a valid start time");
                alert.showAndWait()
                        .filter(res -> res == ButtonType.OK);
       }     

    }
    
}
