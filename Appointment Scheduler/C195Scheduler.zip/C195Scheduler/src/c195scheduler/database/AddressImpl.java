/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.database;

import c195scheduler.Query;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Andrew
 */
public class AddressImpl {
    public static int findMaxAddressId() {
        String query = "SELECT MAX(addressId) FROM address";
        
        try {
            Query.createQuery(query);
            ResultSet rs = Query.queryResult();
            if(rs.next()) {
                return rs.getInt(1);                
            }
        } catch (SQLException e) {
            System.out.println("SQLException: findMaxAddressId():" + e.getMessage());
        }
        return -1;
    }
}
