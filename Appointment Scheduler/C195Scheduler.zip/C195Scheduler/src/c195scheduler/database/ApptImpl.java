/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.database;

import c195scheduler.Query;
import c195scheduler.model.Appointment;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class ApptImpl {
    
    public static void createAppt(String sql) {
        Query.createQuery(sql);
    }
    
    public static void updateAppt(String sql) {

        Query.createQuery(sql);

    }
    
   
    //Returns true if there is an existing appointment for user during proposed timeframe
    public static boolean isOverlapping (Integer userID, LocalDateTime start, LocalDateTime end) throws Exception {
        DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        
        //Convert Local to Zoned, then change to 24-hr format for comparison with database Timestamp
        ZonedDateTime utcStart = start.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
        ZonedDateTime utcEnd = end.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
        String formatStart = dtFormatter.format(utcStart);
        String formatEnd = dtFormatter.format(utcEnd);        

        Timestamp newStart = Timestamp.valueOf(formatStart);
        Timestamp newEnd = Timestamp.valueOf(formatEnd);

        String getAppts = "SELECT start, end FROM appointment WHERE userId = '" + userID + "' AND start > NOW()";

        Query.createQuery(getAppts);
        ResultSet result = Query.queryResult();
        
        try {
            while(result.next()) {
                Timestamp existingStart = result.getTimestamp("start");
                Timestamp existingEnd = result.getTimestamp("end");
                if(existingStart.before(newEnd) && newStart.before(existingEnd)) {
                    return true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error checking ApptImpl:isOverlapping()" + ex.getMessage());
        }
        
        return false;
    }
    
    public static void deleteAppt(int apptID) throws SQLException, Exception{
        String deleteAppt = "DELETE FROM appointment WHERE appointmentId = '" + apptID + "'";
        Query.createQuery(deleteAppt);
    }
    
    public static ObservableList<Appointment> getAllAppointments() throws SQLException, Exception{
        ObservableList<Appointment> allAppts=FXCollections.observableArrayList();    

            String sqlStatement="SELECT * FROM appointment WHERE start >= NOW() AND start <= DATE_ADD(NOW(), interval 1 month)";          
            Query.createQuery(sqlStatement);
            ResultSet result=Query.queryResult();
            
            while(result.next()){
                int apptID=result.getInt("appointmentId");
                int custID=result.getInt("customerId");
                int userID=result.getInt("userId");
                String apptTitle=result.getString("title");
                String apptDescription=result.getString("description");
                String apptLocation=result.getString("location");
                String apptContact=result.getString("contact");
                String apptType=result.getString("type");
                String apptURL=result.getString("url");
                LocalDateTime localStart = (result.getTimestamp("start")).toLocalDateTime();                
                LocalDateTime localEnd = (result.getTimestamp("end")).toLocalDateTime();                
                Timestamp createDate=result.getTimestamp("createDate");
                String createdBy=result.getString("createdBy");
                Timestamp lastUpdate=result.getTimestamp("lastUpdate");
                String lastUpdateby=result.getString("lastUpdateBy");
                Appointment apptResult= new Appointment(apptID, custID, userID, apptTitle, apptDescription, apptLocation, apptContact, apptType, apptURL, localStart, localEnd, createDate, createdBy, lastUpdate, lastUpdateby);
                allAppts.add(apptResult);                
            }

        return allAppts;
    } 

    public static ObservableList<Appointment> getWeeklyAppointments() throws SQLException {
        ObservableList<Appointment> weeklyAppts=FXCollections.observableArrayList(); 
        Timestamp now = Timestamp.from(Instant.now());
        Timestamp weekInAdvance = Timestamp.from(Instant.now().plus(7, ChronoUnit.DAYS));

        String sqlStatement="select * from appointment WHERE start >= '" + now + "' AND start <= '" + weekInAdvance + "'";          
        Query.createQuery(sqlStatement);
        ResultSet result=Query.queryResult();
             while(result.next()){
                int apptID=result.getInt("appointmentId");
                int custID=result.getInt("customerId");
                int userID=result.getInt("userId");
                String apptTitle=result.getString("title");
                String apptDescription=result.getString("description");
                String apptLocation=result.getString("location");
                String apptContact=result.getString("contact");
                String apptType=result.getString("type");
                String apptURL=result.getString("url");
                LocalDateTime localStart = (result.getTimestamp("start")).toLocalDateTime();                
                LocalDateTime localEnd = (result.getTimestamp("end")).toLocalDateTime();
                Timestamp createDate=result.getTimestamp("createDate");
                String createdBy=result.getString("createdBy");
                Timestamp lastUpdate=result.getTimestamp("lastUpdate");
                String lastUpdateby=result.getString("lastUpdateBy");
                Appointment apptResult= new Appointment(apptID, custID, userID, apptTitle, apptDescription, apptLocation, apptContact, apptType, apptURL, localStart, localEnd, createDate, createdBy, lastUpdate, lastUpdateby);
                
                //Only add appointments to list if they are within a week from now
//                if(apptResult.getStart().before(weekInAdvance) && apptResult.getStart().after(Timestamp.from(Instant.now()))) {
                   weeklyAppts.add(apptResult);
//                }
            }
        return weeklyAppts;
    }
    
    public static boolean apptWithinFifteenMinutes() {
        Instant checkedTime = Instant.now().plus(15, ChronoUnit.MINUTES);
        Instant startTime = Instant.now();
        Integer userID = UserImpl.getCurrentUser().getUserID();
        
        String query = "SELECT * FROM appointment WHERE start BETWEEN '" + startTime + "' AND '" + checkedTime + "' AND " + 
            "userId = '" + userID + "'";
        try {            
            Query.createQuery(query);
            ResultSet rs = Query.queryResult();
            if(rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: apptWithinFifteenMinutes():" + e.getMessage());
        }
        return false;
    }
    
    public static int findMaxApptId() {
        String query = "SELECT MAX(appointmentId) FROM appointment";
        
        try {
            Query.createQuery(query);
            ResultSet rs = Query.queryResult();
            if(rs.next()) {
                return rs.getInt(1);                
            }
        } catch (SQLException e) {
            System.out.println("SQLException: findMaxApptId():" + e.getMessage());
        }
        return -1;
    }
    
}
