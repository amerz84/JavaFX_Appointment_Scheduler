/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.database;

import c195scheduler.DBConnect;
import c195scheduler.Query;
import c195scheduler.model.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class UserImpl {
    static boolean act;
    private static User currentUser;
    public static User getUser(String userName) throws SQLException, Exception{

        String sqlStatement="SELECT * FROM user WHERE userName  = '" + userName+ "'";
        Query.createQuery(sqlStatement);
           User userResult;
           ResultSet result=Query.queryResult();
           while(result.next()){
                int userid=result.getInt("userId");
                String uName=result.getString("userName");
                String password=result.getString("password");
                int active=result.getInt("active");
                if(active==1) act=true;
                Instant createDate=result.getTimestamp("createDate").toInstant();
                String createdBy=result.getString("createdBy");
                Instant lastUpdate=result.getTimestamp("lastUpdate").toInstant();
                String lastUpdateby=result.getString("lastUpdateBy");   
                
                userResult= new User(userid, uName, password, act, createDate, createdBy, lastUpdate, lastUpdateby);
                return userResult;
           }

        return null;
    }
    
    public static void setCurrentUser(User user) {
        currentUser = user;
    }
    
    public static User getCurrentUser() {
        return currentUser;
    }
    
    public static ObservableList<User> getAllUsers() throws SQLException, Exception{
        ObservableList<User> allUsers=FXCollections.observableArrayList();    

            String sqlStatement="select * from user";          
            Query.createQuery(sqlStatement);
            ResultSet result=Query.queryResult();
             while(result.next()){
                int userid=result.getInt("userid");
                String uName=result.getString("userName");
                String password=result.getString("password");
                int active=result.getInt("active");
                if(active==1) act=true;
                Instant createDate=result.getTimestamp("createDate").toInstant();
                String createdBy=result.getString("createdBy");
                Instant lastUpdate=result.getTimestamp("lastUpdate").toInstant();
                String lastUpdateby=result.getString("lastUpdateBy");   
                
                User userResult= new User(userid, uName, password, act, createDate, createdBy, lastUpdate, lastUpdateby);
                allUsers.add(userResult);
                
            }

        return allUsers;
    } 
}
