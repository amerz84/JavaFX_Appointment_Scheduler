/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.database;

import c195scheduler.DBConnect;
import c195scheduler.Query;
import c195scheduler.model.Customer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class CustomerImpl {
    static boolean act;
    
    public static Customer getCustomer(String custName) throws SQLException, Exception{

        String sqlStatement="select * FROM customer WHERE customerName  = '" + custName+ "'";
        Query.createQuery(sqlStatement);
           Customer custResult;
           ResultSet result=Query.queryResult();
           while(result.next()){
                int custID=result.getInt("customerId");
                String cName=result.getString("customerName");
                int addressID=result.getInt("addressId");
                int active=result.getInt("active");
                if(active==1) act=true;
                Instant createDate=result.getTimestamp("createDate").toInstant();
                String createdBy=result.getString("createdBy");
                Instant lastUpdate=result.getTimestamp("lastUpdate").toInstant();
                String lastUpdateby=result.getString("lastUpdateBy");           
           
                custResult= new Customer(custID, cName, addressID, act, createDate, createdBy, lastUpdate, lastUpdateby);
                return custResult;
           }

        return null;
    }
    
    public static ObservableList<Customer> getAllCustomers() throws SQLException, Exception{
        ObservableList<Customer> allCustomers=FXCollections.observableArrayList();    

            String sqlStatement="select * from customer";          
            Query.createQuery(sqlStatement);
            ResultSet result=Query.queryResult();
             while(result.next()){
                int custID =result.getInt("customerId");
                String custName=result.getString("customerName");
                int addressID=result.getInt("addressId");
                int active=result.getInt("active");
                if(active==1) act=true;
                Instant createDate=result.getTimestamp("createDate").toInstant();
                String createdBy=result.getString("createdBy");
                Instant lastUpdate=result.getTimestamp("lastUpdate").toInstant();
                String lastUpdateby=result.getString("lastUpdateBy");  

                Customer custResult= new Customer(custID, custName, addressID, act, createDate, createdBy, lastUpdate, lastUpdateby);
                allCustomers.add(custResult);
                
            }

        return allCustomers;
    } 
    
    public static void deleteCustomer(int custID) throws SQLException, Exception{
        String deleteAppt = "DELETE FROM customer WHERE customerId = '" + custID + "'";
        Query.createQuery(deleteAppt); 
    }
    
    public static int findMaxCustomerId() {
        String query = "SELECT MAX(customerId) FROM customer";
        
        try {
            Query.createQuery(query);
            ResultSet rs = Query.queryResult();
            if(rs.next()) {
                return rs.getInt(1);                
            }
        } catch (SQLException e) {
            System.out.println("SQLException: findMaxCustomerId():" + e.getMessage());
        }
        return -1;
    }
}
