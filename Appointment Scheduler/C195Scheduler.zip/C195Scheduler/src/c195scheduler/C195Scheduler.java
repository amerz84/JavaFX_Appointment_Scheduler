/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler;

import c195scheduler.model.Address;
import c195scheduler.model.City;
import c195scheduler.model.Country;
import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Andrew
 */
public class C195Scheduler extends Application {
       
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        DBConnect.createConnection();
        Address.setAddresses();
        City.setCities();
        Country.setCountries();
        launch(args);
        DBConnect.closeConnection();
    }

   @Override
    public void start(Stage stage) throws Exception {
        ResourceBundle languageBundle = ResourceBundle.getBundle("c195scheduler/utilities/Login", Locale.getDefault()); // Properties file for language (French)
        
        Parent root = null;
        
        // Pass resource bundle to FXML controller
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginScreen.fxml"));
            loader.setResources(languageBundle);
            root = loader.load();
        
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
        } 
        catch(IOException ex) {
            ex.printStackTrace();
        }
    }  
}
