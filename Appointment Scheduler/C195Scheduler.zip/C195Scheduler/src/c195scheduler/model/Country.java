/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import c195scheduler.Query;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class Country {
    private IntegerProperty countryID;
    private StringProperty country;
    private ZonedDateTime createDate;
    private StringProperty createdBy;
    private ZonedDateTime lastUpdate;
    private StringProperty lastUpdateBy;
    private static ObservableList<Country> allCountries = FXCollections.observableArrayList();

    public Country(int countryID, String country, ZonedDateTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdateBy) {
        this.countryID = new SimpleIntegerProperty(countryID);
        this.country = new SimpleStringProperty(country);
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
    }
    
    public void setCountryID(int countryID) {
        this.countryID.set(countryID);
    }

    public void setCountry(String country) {
        this.country.set(country);
    }

    public void setCreateDate(ZonedDateTime createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate(ZonedDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }

    public int getCountryID() {
        return countryID.get();
    }

    public String getCountry() {
        return country.get();
    }

    public ZonedDateTime getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public ZonedDateTime getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }
    
    public static void setCountries() {
        String countries = "SELECT * from country";
        Query.createQuery(countries);
        
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {
                Country country = new Country(rs.getInt(1), rs.getString(2), ZonedDateTime.now(), rs.getString(4), ZonedDateTime.now(), rs.getString(6));
                allCountries.add(country);
            }
        } catch (SQLException ex) {
            System.out.println("Error in Country:setCountries()");
        }
    }
    
    public static ObservableList<Country> getCountries() {
        return allCountries;
    } 
}
