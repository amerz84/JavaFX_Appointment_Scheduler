/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import java.time.Instant;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class User {
    private IntegerProperty userID;
    private StringProperty userName;
    private StringProperty password;
    private boolean active = false;
    private Instant createDate;
    private StringProperty createdBy;
    private Instant lastUpdate;
    private StringProperty lastUpdateBy;
    private static ObservableList<User> userList = FXCollections.observableArrayList();

    public User(int userID, String userName, String password, boolean active, Instant createDate, String createdBy, Instant lastUpdate, String lastUpdateBy) {
        this.userID = new SimpleIntegerProperty(userID);
        this.password = new SimpleStringProperty(password);
        this.userName = new SimpleStringProperty(userName);
        this.active = active;
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
        
    }
    
    public void setUserID(int userID) {
        this.userID.set(userID);
    }

    public void setUserName(String userName) {
        this.userName.set(userName);
    }
    
    public void setPassword(String password) {
        this.password.set(password);
    }
    
    public void setActive() {
        this.active = true;
    }
    
    public void setCreateDate() {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate() {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }
    
    public int getUserID() {
        return userID.get();
    }
    
    public String getUserName() {
        return userName.get();
    }
    
    public String getPassword() {
        return password.get();
    }
    
    public Boolean isActive() {
        return active;
    }

    public Instant getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public Instant getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }
    
}
