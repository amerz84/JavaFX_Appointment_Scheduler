/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import c195scheduler.Query;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class Address {
    private IntegerProperty addressID;
    private StringProperty address;
    private StringProperty address2;
    private IntegerProperty cityID;
    private StringProperty postalCode;
    private StringProperty phone;
    private Timestamp createDate;
    private StringProperty createdBy;
    private Timestamp lastUpdate;
    private StringProperty lastUpdateBy;
    private static ObservableList<Address> allAddresses = FXCollections.observableArrayList();

    public Address(int addressID, String address, String address2, int cityID, String postalCode, String phone, Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdateBy) {
        this.addressID = new SimpleIntegerProperty(addressID);
        this.address = new SimpleStringProperty(address);
        this.address2 = new SimpleStringProperty(address2);
        this.cityID = new SimpleIntegerProperty(cityID);
        this.postalCode = new SimpleStringProperty(postalCode);
        this.phone = new SimpleStringProperty(phone);
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
    }
    
    public void setAddressID(int addressID) {
        this.addressID.set(addressID);
    }
    
    public void setAddress(String address) {
        this.address.set(address);
    }

    public void setAddress2(String address2) {
        this.address2.set(address2);
    }
    
    public void setCityID(int cityID) {
        this.cityID.set(cityID);
    }
    
    public void setPostalCode(String postalCode) {
        this.postalCode.set(postalCode);
    }
    
    public void setPhone(String phone) {
        this.phone.set(phone);
    }
    
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }
    
    public int getAddressID() {
        return addressID.get();
    }
    
    public String getAddress() {
        return address.get();
    }
    
    public String getAddress2() {
        return address2.get();
    }
    
    public int getCityID() {
        return cityID.get();
    }
    
    public String getPostalCode() {
        return postalCode.get();
    }
    
    public String getPhone() {
        return phone.get();
    }
    
    public Timestamp getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }
    
    public static void setAddresses() {
        String addresses = "SELECT * from address";
        Query.createQuery(addresses);
        
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {
                Address address = new Address(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4),rs.getString(5), rs.getString(6), rs.getTimestamp(7), rs.getString(8), rs.getTimestamp(9), rs.getString(10));
                allAddresses.add(address);
            }
        } catch (SQLException ex) {
            System.out.println("Error in Address:setAddresses()");
        }
    }
    
    public static ObservableList<Address> getAddresses() {
        return allAddresses;
    } 
    
    public static void updateAddress(String sql) {

        Query.createQuery(sql);

    }
}
