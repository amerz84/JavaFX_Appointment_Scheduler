/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import c195scheduler.Query;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class City {
    private IntegerProperty cityID;
    private StringProperty city;
    private IntegerProperty countryID;
    private ZonedDateTime createDate;
    private StringProperty createdBy;
    private ZonedDateTime lastUpdate;
    private StringProperty lastUpdateBy;
    private static ObservableList<City> allCities = FXCollections.observableArrayList();
   
    public City(int cityID, String city, int countryID, ZonedDateTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdateBy) {
        this.cityID = new SimpleIntegerProperty(cityID);
        this.city = new SimpleStringProperty(city);
        this.countryID = new SimpleIntegerProperty(countryID);
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
    }
    
    public void setCityID(int cityID){
        this.cityID.set(cityID);
    }
    
    public void setCity(String city) {
        this.city.set(city);
    }
    
    public void setCountryID(int countryID) {
        this.countryID.set(countryID);
    }

    public void setCreateDate(ZonedDateTime createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate(ZonedDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }

    public int getCityID() {
        return cityID.get();
    }

    public String getCity() {
        return city.get();
    }
    
    public int getCountryID() {
        return countryID.get();
    }

    public ZonedDateTime getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public ZonedDateTime getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }
    
    public static void setCities() {
        String cities = "SELECT * from city";
        Query.createQuery(cities);
        
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {
                City city = new City(rs.getInt(1), rs.getString(2), rs.getInt(3), ZonedDateTime.now(), rs.getString(5), ZonedDateTime.now(), rs.getString(7));
                allCities.add(city);
            }
        } catch (SQLException ex) {
            System.out.println("Error in City:setCities()");
        }
    }
    
    public static ObservableList<City> getCities() {
        return allCities;
    } 
}