/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import c195scheduler.utilities.DateFormats;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Andrew
 */
public class Appointment {
    private IntegerProperty appointmentID;
    private IntegerProperty customerID;
    private IntegerProperty userID;
    private StringProperty title;
    private StringProperty description;
    private StringProperty location;
    private StringProperty contact;
    private StringProperty type;
    private StringProperty url;
    private LocalDateTime start;
    private LocalDateTime end;
    private Timestamp createDate;
    private StringProperty createdBy;
    private Timestamp lastUpdate;
    private StringProperty lastUpdateBy;

    
    public Appointment() { super();}
    public Appointment(int apptID, int custID, int userID, String title, String description, String location, String contact, String type, String url, LocalDateTime start, LocalDateTime end, Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdateBy) {
        this.appointmentID = new SimpleIntegerProperty(apptID);
        this.customerID = new SimpleIntegerProperty(custID);
        this.userID = new SimpleIntegerProperty(userID);
        this.title = new SimpleStringProperty(title);
        this.description = new SimpleStringProperty(description);
        this.location = new SimpleStringProperty(location);
        this.contact = new SimpleStringProperty(contact);
        this.type = new SimpleStringProperty(type);
        this.url = new SimpleStringProperty(url);
        this.start = start;
        this.end = end;
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
        
    }

    public void setAppointmentID(int apptID) {
        this.appointmentID.set(apptID);       
    }
    
    public void setCustomerID(int customerID) {
        this.customerID.set(customerID);
    }
    
    public void setUserID(int userID) {
        this.userID.set(userID);
    }
    
    public void setTitle(String title) {
        this.title.set(title);
    }
    
    public void setDescription(String description) {
        this.description.set(description);
    }
    
    public void setLocation(String location) {
        this.location.set(location);
    }
    
    public void setContact(String contact) {
        this.contact.set(contact);
    }
    
    public void setType(String type) {
        this.type.set(type);
    }
    
    public void setURL(String url) {
        this.url.set(url);
    }
    
    public void setStart(LocalDateTime start) {
        this.start = start;
    }
    
    public void setEnd(LocalDateTime end) {
        this.end = end;
    }
    
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }
    
    public int getAppointmentID() throws Exception {
        return appointmentID.get();
    }
    
    public int getCustomerID() {
        return customerID.get();
    }
    
    public int getUserID() {
        return userID.get();
    }
    
    public String getTitle() {
        return title.get();
    }
    
    public String getDescription() {
        return description.get();
    }
    
    public String getLocation() {
        return location.get();
    }
    
    public String getContact() {
        return contact.get();
    }
    
    public String getType() {
        return type.get();
    }
    
    public String getURL() {
        return url.get();
    }
    
    public String getStart() {
        return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(start.toInstant(ZoneOffset.UTC), ZoneId.systemDefault()));         
    }  
    
    public String getEnd() {
        return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(end.toInstant(ZoneOffset.UTC), ZoneId.systemDefault())); 
    }
    
    public Timestamp getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }    
}
