/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.model;

import java.time.Instant;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class Customer {
    private IntegerProperty customerID;
    private StringProperty customerName;
    private IntegerProperty addressID;
    private boolean active = false;
    private Instant createDate;
    private StringProperty createdBy;
    private Instant lastUpdate;
    private StringProperty lastUpdateBy;    
    private static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
    
    public Customer(int customerID, String customerName, int addressID, boolean active, Instant createDate, String createdBy, Instant lastUpdate, String lastUpdateBy) {
        this.customerID = new SimpleIntegerProperty(customerID);
        this.customerName = new SimpleStringProperty(customerName);
        this.addressID = new SimpleIntegerProperty(addressID);
        this.active = active;
        this.createDate = createDate;
        this.createdBy = new SimpleStringProperty(createdBy);
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = new SimpleStringProperty(lastUpdateBy);
    }

    public void setCustomerID(int customerID) {
        this.customerID.set(customerID);
    }
    
    public void setCustomerName(String customerName) {
        this.customerName.set(customerName);
    }
    
    public void setAddressID(int addressID) {
        this.addressID.set(addressID);
    }
    
    public void setActive(boolean active) {
        this.active = active;
    }
    
    public void setCreateDate(Instant createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setLastUpdate(Instant lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy.set(lastUpdateBy);
    }
    
    public int getCustomerID() {
        return customerID.get();
    }
    
    public String getCustomerName() {
        return customerName.get();
    }
    
    public int getAddressID() {
        return addressID.get();
    }
    
    public Boolean isActive() {
        return active;
    }
    
    public Instant getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public Instant getLastUpdate() {
        return lastUpdate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy.get();
    }

    
}
