/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.utilities;

import c195scheduler.Query;
import c195scheduler.model.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class ReportGenerator {
    
    //Inner class for ApptTypeReport
    public static class ApptTypeList{
        StringProperty apptType;
        IntegerProperty total;
        
        public ApptTypeList(StringProperty apptType, IntegerProperty total) {
            this.apptType = apptType;
            this.total = total;
        }        
        public int getTotal() {
            return total.get();
        }
        public String getApptType() {
            return apptType.get();
        }
    }
    
    //Inner class for Schedule report
    public static class ScheduleList {
        IntegerProperty appointmentId;
        StringProperty customerName;
        StringProperty start;
        StringProperty end;
        
        public ScheduleList(IntegerProperty appointmentId, StringProperty customerName, StringProperty start, StringProperty end){
            this.appointmentId = appointmentId;
            this.customerName = customerName;
            this.start = start;
            this.end = end;           
        }
        
        public int getAppointmentId() {
            return appointmentId.get();
        }
        
        public String getCustomerName() {
            return customerName.get();
        }
        
        public String getStart() {
            String formattedStart = start.get().replaceAll("\\s","T");
            return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(LocalDateTime.parse(formattedStart).toInstant(ZoneOffset.UTC), ZoneId.systemDefault()));
        }
        
        public String getEnd() {
            String formattedEnd = end.get().replaceAll("\\s","T");
            return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(LocalDateTime.parse(formattedEnd).toInstant(ZoneOffset.UTC), ZoneId.systemDefault()));
        }
    }
    
    //Inner class for Date report
    public static class DateList {
        StringProperty userName;
        StringProperty customerName;
        StringProperty start;
        StringProperty end;
        
        public DateList(StringProperty customerName, StringProperty userName, StringProperty start, StringProperty end) {
            this.customerName = customerName;
            this.userName = userName;
            this.start = start;
            this.end = end;
        }
        
        public String getUserName() {
            return userName.get();
        }
        
        public String getCustomerName() {
            return customerName.get();            
        }
        
        public String getStart() {
            String formattedStart = start.get().replaceAll("\\s","T");
            return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(LocalDateTime.parse(formattedStart).toInstant(ZoneOffset.UTC), ZoneId.systemDefault()));
        }
         
        public String getEnd() {
            String formattedEnd = end.get().replaceAll("\\s","T");
            return DateFormats.DateTimeFormat(LocalDateTime.ofInstant(LocalDateTime.parse(formattedEnd).toInstant(ZoneOffset.UTC), ZoneId.systemDefault()));
        }
    }
    
    public static ObservableList<ApptTypeList> getAppointmentTypes() {
        ObservableList<ApptTypeList> obsApptTypeList = FXCollections.observableArrayList();
        String typeQuery = "SELECT type, COUNT(*) as Total"
                + " FROM appointment"
                + " GROUP BY type";        

        Query.createQuery(typeQuery);
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {                
                StringProperty apptType = new SimpleStringProperty(rs.getString("type"));
                IntegerProperty total = new SimpleIntegerProperty(rs.getInt("Total"));
                obsApptTypeList.add(new ApptTypeList(apptType, total));                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ReportGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }   

        return obsApptTypeList;        
    }
    
    public static ObservableList<ScheduleList> getSchedule(User user) {
        ObservableList<ScheduleList> obsUserSchedule = FXCollections.observableArrayList();

        String scheduleQuery = "SELECT  a.appointmentId, c.customerName, a.start, a.end" +
            " FROM appointment a JOIN customer c" +
            " ON a.customerId = c.customerId " +
            " WHERE a.userId = '" + user.getUserID() + "' " +
            " ORDER BY start";
        
        Query.createQuery(scheduleQuery);
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {

                IntegerProperty apptID = new SimpleIntegerProperty(rs.getInt("appointmentId"));
                StringProperty custName = new SimpleStringProperty(rs.getString("customerName")); 
                StringProperty start = new SimpleStringProperty(rs.getTimestamp("start").toString());
                StringProperty end = new SimpleStringProperty(rs.getTimestamp("end").toString());
                obsUserSchedule.add(new ScheduleList(apptID, custName, start, end));
            }            
        }
        catch (SQLException ex) {
            Logger.getLogger(ReportGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obsUserSchedule;
    }
    
    
    public static ObservableList<DateList> getAppointmentDates() {
        ObservableList<DateList> apptDateList = FXCollections.observableArrayList();

        String dateQuery = "SELECT c.customerName, u.userName, a.start, a.end "
                + "FROM appointment a "
                + "JOIN customer c ON a.customerId = c.customerId "
                + "JOIN user u ON a.userId = u.userId "
                + "ORDER BY start, c.customerName";
        
        Query.createQuery(dateQuery);
        ResultSet rs = Query.queryResult();
        
        try {
            while(rs.next()) {

                StringProperty customerName = new SimpleStringProperty(rs.getString("customerName"));
                StringProperty userName = new SimpleStringProperty(rs.getString("userName")); 
                StringProperty start = new SimpleStringProperty(rs.getTimestamp("start").toString());
                StringProperty end = new SimpleStringProperty(rs.getTimestamp("end").toString());
                apptDateList.add(new DateList(customerName, userName, start, end));
            }

        }
        catch (SQLException ex) {
            Logger.getLogger(ReportGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return apptDateList;
    }
}
