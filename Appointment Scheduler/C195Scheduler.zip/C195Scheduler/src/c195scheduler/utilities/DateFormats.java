/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195scheduler.utilities;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Andrew
 */
public class DateFormats {
    static ZonedDateTime zonedDT;
    static ZoneId defaultZone = ZoneId.systemDefault();
    
    //Format LocalDateTime and add AM/PM - for Table display
    public static String DateTimeFormat(LocalDateTime datetime) {
        String amOrPm = null;
        int hours = datetime.getHour();
        
        
        String formattedDT;
        DateTimeFormatter f = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
        
        if (hours > 12) {
            formattedDT = f.format(datetime.minus(12, ChronoUnit.HOURS));
            amOrPm = "PM";
        }
        else {
            formattedDT = f.format(datetime);
            amOrPm = "AM";
        }
        return formattedDT + " " + amOrPm;
    }    
    
}
